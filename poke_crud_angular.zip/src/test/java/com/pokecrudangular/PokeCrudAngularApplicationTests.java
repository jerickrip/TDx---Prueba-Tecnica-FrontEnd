package com.pokecrudangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokeCrudAngularApplicationTests {

	@Test
	void contextLoads() {
	}

}
